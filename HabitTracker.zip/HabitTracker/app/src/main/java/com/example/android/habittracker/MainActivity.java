package com.example.android.habittracker;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.android.habittracker.mydata.Contract;
import com.example.android.habittracker.mydata.Helper;

public class MainActivity extends AppCompatActivity {
    Helper dataHelper = new Helper(this);
    Cursor cursor;

    public Cursor singleRead() {
        SQLiteDatabase dp = dataHelper.getReadableDatabase();
        cursor = dp.query(Contract.Habits.TABLE_NAME, null, null, null, null, null, null);
        return cursor;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Setup FAB to open EditorActivity
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, EditHabits.class);
                startActivity(intent);
            }
        });
        displayDatabaseInfo();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu options from the res/menu/menu_catalog.xml file.
        // This adds menu items to the app bar.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Insert dummy data" menu option
            case R.id.action_insert_dummy_data:
                insertDumyData();
                displayDatabaseInfo();

                return true;
            // Respond to a click on the "Delete all entries" menu option
            case R.id.action_delete_all_entries:
                // Do nothing for now
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void insertDumyData() {
        ContentValues values = new ContentValues();
        values.put(Contract.Habits.COLUMN_NAME, "football");
        values.put(Contract.Habits.COLUMN_DISCRIPTION, "all day");
        values.put(Contract.Habits.COLUMN_TYPE, Contract.Habits.TYPE_SPORT);
        values.put(Contract.Habits.COLUMN_LOVE_IT, Contract.Habits.LOVE_MOST);

        SQLiteDatabase dp = dataHelper.getReadableDatabase();
        dp.insert(Contract.Habits.TABLE_NAME, null, values);
    }
    private void displayDatabaseInfo() {

        singleRead();

        //to display the result data
        TextView displayView = (TextView) findViewById(R.id.text_view_pet);
        displayView.setText("Number of current pets in Pets_table is : [" + cursor.getCount() + "] pets\n \n \n" + Contract.Habits._ID + "      |       " + Contract.Habits.COLUMN_NAME + "    |    " +
                Contract.Habits.COLUMN_DISCRIPTION + "   |   " + Contract.Habits.COLUMN_TYPE + "   |   " + Contract.Habits.COLUMN_LOVE_IT + "\n \n ");

        //get indecies of all columns in the table
        int IDIndexColumn = cursor.getColumnIndex(Contract.Habits.COLUMN_ID);
        int NameIndexColumn = cursor.getColumnIndex(Contract.Habits.COLUMN_NAME);
        int BreedIndexColumn = cursor.getColumnIndex(Contract.Habits.COLUMN_DISCRIPTION);
        int GenderIndexColumn = cursor.getColumnIndex(Contract.Habits.COLUMN_TYPE);
        int WeightIndexColumn = cursor.getColumnIndex(Contract.Habits.COLUMN_LOVE_IT);

        try {

            //move to the upest of the table in then move next
            while (cursor.moveToNext()) {
                //get the data inside this specific place with {index} and {position}
                int id = cursor.getInt(IDIndexColumn);
                String name = cursor.getString(NameIndexColumn);
                String breed = cursor.getString(BreedIndexColumn);
                int gender = cursor.getInt(GenderIndexColumn);
                int weight = cursor.getInt(WeightIndexColumn);

                displayView.append(id + "      |       " + name + "    |    " +
                        breed + "   |   " + gender + "   |   " + weight + "\n ");
                displayView.append("---------------------------------------------------------------- \n");
            }
            // Display the number of rows in the Cursor (which reflects the number of rows in the
            // pets table in the database).1
        } finally {
            // Always close the cursor when you're done reading from it. This releases all its
            // resources and makes it invalid.
            cursor.close();
        }
    }
}
