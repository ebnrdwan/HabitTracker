package com.example.android.habittracker.mydata;

import android.provider.BaseColumns;

/**
 * Created by Abdulrhman on 16/10/2016.
 */
public final   class Contract {

    public Contract() {
    }

    public static class Habits implements BaseColumns{
        //table name constant
        public static String TABLE_NAME = "habits";
        // columns name constans
        public static String COLUMN_ID = BaseColumns._ID;
        public static String COLUMN_NAME = "name";
        public static String COLUMN_DISCRIPTION= "discription";
        public static String COLUMN_TYPE = "type";
        public static String COLUMN_LOVE_IT = "love_it";


        public static int TYPE_SPORT = 1;
        public static int TYPE_SPIRIT = 2;
        public static int TYPE_RELATIONSHIP=3;

        public static int LOVE_MOST=1;
        public static int LOVE_AVG =2;
        public static int LOVE_LOW=3;

    }

}
