package com.example.android.habittracker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class EditHabits extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_habits_activity);
    }
}
