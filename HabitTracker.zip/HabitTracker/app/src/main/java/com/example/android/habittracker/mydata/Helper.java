package com.example.android.habittracker.mydata;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


/**
 * Created by Abdulrhman on 16/10/2016.
 */
public class Helper extends SQLiteOpenHelper {
    public static String dpName = "habits.dp";
    public static int dpVersion = 1;

    public Helper(Context context) {
        super(context, dpName, null, dpVersion);
    }

    /*
    id auto primary key'
    name not null
    disc text
    type not null
     */
    String SQL_CREATE = "CREATE TABLE " + Contract.Habits.TABLE_NAME + " ( " + Contract.Habits.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
            + Contract.Habits.COLUMN_NAME + " TEXT , " + Contract.Habits.COLUMN_DISCRIPTION + " TEXT, " + Contract.Habits.COLUMN_TYPE + " INTEGER , " + Contract.Habits.COLUMN_LOVE_IT + " INTEGER );";

    //delete SQL STATEMENT
    String SQL_DELETE = "DROP TABLE IF EXISTS " + Contract.Habits.TABLE_NAME;
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(SQL_CREATE);
        Log.d("LOGLOG", SQL_CREATE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL(SQL_DELETE);
        onCreate(sqLiteDatabase);
    }
}
